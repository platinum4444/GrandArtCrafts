import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privacy-po',
  templateUrl: './privacy-po.component.html',
  styleUrls: ['./privacy-po.component.css']
})
export class PrivacyPoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

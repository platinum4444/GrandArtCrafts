(function hello() {

})()
